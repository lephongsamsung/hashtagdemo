import SidebarDemo from "../sidebar-demo"

export default function Page() {
  return <SidebarDemo />
}
